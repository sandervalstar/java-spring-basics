package config;

import org.springframework.context.annotation.ComponentScan;

@ComponentScan(basePackages = {"logic"})
public class AppContext {

}
