package logic.dispenser;

import domain.Milk;

public interface MilkDispenser {
    void dispense(Milk coffee, int percentage);
}
