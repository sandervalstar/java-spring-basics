package logic.dispenser;


import domain.Sugar;

public interface SugarDispenser {
    void dispense(Sugar coffee, int percentage);
}
