package domain;

public class Milk extends Ingredient {

    public Milk(long id, String name) {
        super(id, name);
    }
}
